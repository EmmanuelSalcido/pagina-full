'use strict'

console.log ('Hola mundo desde Node.js, esto se vera en la terminal de comandos')
console.log(2.5)
//console.log(window)
console.log(global)
setInterval(function(){
    console.log('hola nodejs')
},1000)